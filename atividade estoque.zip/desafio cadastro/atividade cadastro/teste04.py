import pandas as pd
import os


ESTOQUE_FILE = r"C:\Users\rosec\Downloads\desafio cadastro\atividade cadastro\estoque_loja_pecas.xlsx"
df_estoque_global = None 
ESTOQUE_COUNT_SEGURO = 0 
estoque = None

UNIDADES_VALIDAS = ["CX", "KG", "L", "UN"]

# --- FUNÇÕES DE ARQUIVO E ESTOQUE PRINCIPAL ---

def carregar_estoque():
    """Tenta carregar os produtos do Excel de forma segura."""
    global df_estoque_global, ESTOQUE_COUNT_SEGURO
    
    if os.path.exists(ESTOQUE_FILE):
        try:
            df_estoque_global = pd.read_excel(ESTOQUE_FILE)
            
            if "Código" in df_estoque_global.columns:
                df_estoque_global["Código"] = df_estoque_global["Código"].astype(str).str.strip().str.upper()

            ESTOQUE_COUNT_SEGURO = len(df_estoque_global)
            print(f"\n[SUCESSO] Planilha '{os.path.basename(ESTOQUE_FILE)}' carregada com {ESTOQUE_COUNT_SEGURO} itens.")
            return df_estoque_global.to_dict(orient="records")
        except Exception as e:
            print(f"Erro ao carregar o arquivo '{os.path.basename(ESTOQUE_FILE)}': {e}")
            print("Verifique se o arquivo está fechado e no formato correto.")
    
    print(f"Aviso: Arquivo '{os.path.basename(ESTOQUE_FILE)}' não encontrado ou leitura falhou. Iniciando em MODO DE SEGURANÇA.")
    
    df_estoque_global = None 
    return None 

def salvar_estoque(estoque_lista):
    """Salva os produtos da lista em memória no Excel."""
    global df_estoque_global
    

    if estoque_lista is None:
        print("\n[ERRO DE SEGURANÇA] O estoque principal não foi carregado. Operação de salvamento bloqueada.")
        return

    colunas = ["Código", "Descrição do Item", "Categoria", "Unidade", "Valor Unitário", "Quantidade", "Valor Total"]
    
    df_estoque_global = pd.DataFrame(estoque_lista, columns=colunas)
    df_estoque_global.to_excel(ESTOQUE_FILE, index=False)
    print(f"Estoque atualizado no Excel. Total de itens salvos: {len(estoque_lista)}")


def obter_dados_item():
    """Pede e retorna os dados do item, com validação da unidade e campo de Quantidade separado."""
    print("-" * 30)
    codigo = input("Código do item: ").upper().strip() 
    descricao = input("Descrição do Item: ").strip()
    categoria = input("Categoria (Matéria-Prima ou Produto Acabado): ").strip()
    
    while True:
        unidade = input(f"Unidade (Aceita apenas {', '.join(UNIDADES_VALIDAS)}): ").upper().strip()
        if unidade in UNIDADES_VALIDAS:
            break
        print(f"Unidade inválida. Por favor, digite uma das opções: {', '.join(UNIDADES_VALIDAS)}")

    try:
        quantidade = int(input("Quantidade: "))
        valor_un = float(input("Valor Unitário (R$): "))
        valor_total = valor_un * quantidade
        
    except ValueError:
        print("Entrada inválida para Quantidade ou Valor. Usando 0.")
        valor_un = 0.0
        quantidade = 0
        valor_total = 0.0
        
    return {
        "Código": codigo, 
        "Descrição do Item": descricao, 
        "Categoria": categoria, 
        "Unidade": unidade, # Agora armazena apenas a sigla (cx, kg, L, un)
        "Valor Unitário": valor_un,
        "Quantidade": quantidade, # Armazena o número inteiro
        "Valor Total": valor_total
    }


def exibir_pilha(estoque_lista, titulo="Pilha de Produtos"):
    """Exibe os itens em formato de pilha, na ordem solicitada: CÓDIGO | DESCRIÇÃO | UND | QTD | R$ UN | R$ TOTAL."""
    if estoque_lista is None or not estoque_lista:
        print("\nNenhum produto carregado/cadastrado.")
        return
        
    print(f"\n--- {titulo} ({len(estoque_lista)} Itens) ---")
    print(f"{'CÓDIGO':<10} | {'DESCRIÇÃO DO ITEM':<30} | {'UND':<8} | {'QTD':<5} | {'R$ UN':<10} | {'R$ TOTAL':<12}")
    print("-" * 90)
    itens_para_exibir = list(reversed(estoque_lista))[:10]

    for produto in itens_para_exibir:
        valor_un = produto.get("Valor Unitário", 0.0)
        quantidade = produto.get("Quantidade", 0)
        valor_total_exibicao = produto.get("Valor Total", valor_un * quantidade)
        
        print(
            f"{produto['Código']:<10} | "
            f"{produto['Descrição do Item']:<30} | "
            f"{produto['Unidade']:<8} | "
            f"{quantidade:<5} | "
            f"R$ {valor_un:<5.2f} | "
            f"R$ {valor_total_exibicao:<7.2f}"
        )
    
    if len(estoque_lista) > 10:
        print(f"Total: {len(estoque_lista)} itens. Mostrando apenas os últimos 10.")
    print("-" * 90)


def consultar_ou_visualizar(estoque_lista):
    """Consulta um item (Opção 2) ou visualiza a lista completa (Opção 3)."""
    global df_estoque_global

    if estoque_lista is None:
        print("[BLOQUEADO] Estoque principal não carregado. Corrija o arquivo Excel.")
        return
        
    print("\n--- CONSULTA/VISUALIZAÇÃO ---")
    while True:
        opcao = input("Deseja (1) Consultar por Código ou (2) Visualizar a Lista Completa? (1/2): ").strip()

        if opcao == "2":
            exibir_pilha(estoque_lista, titulo="Estoque Principal Completo") 
            break
        
        elif opcao == "1":
            codigo = input("Digite o código do item (ou 'sair' para voltar): ").upper().strip()
            if codigo == "SAIR":
                break

            item = df_estoque_global[df_estoque_global["Código"] == codigo]
            
            if not item.empty:
                print("\nItem encontrado (do Estoque Carregado):")
                print(item.to_string(index=False))
            else:
                print("Código não encontrado.")
        else:
            print("Opção inválida. Digite 1 ou 2.")
            break 

def excluir_item(estoque_lista):
    """Remove um item do estoque pelo código e salva a alteração."""
    
    if estoque_lista is None:
        print("[BLOQUEADO] Estoque principal não carregado. Corrija o arquivo Excel.")
        return
        
    if not estoque_lista:
        print("\nNenhum produto para excluir.")
        return
        
    codigo = input("Digite o código do item para excluir: ").upper().strip()
    
    estoque_atualizado = [produto for produto in estoque_lista if produto["Código"] != codigo]
    
    if len(estoque_atualizado) < len(estoque_lista):
        estoque_lista[:] = estoque_atualizado
        print(f"\nProduto {codigo} excluído com sucesso!")
        salvar_estoque(estoque_lista)
    else:
        print("Código não encontrado na pilha atual.")


def menu_exportacao_final(dados):
    """Pergunta sobre a exportação, e adiciona os itens novos à lista principal."""
    global estoque
    
    if not dados:
        print("Nenhum item cadastrado para exportação.")
        return
    
    if estoque is None:
        print("[BLOQUEADO] Estoque principal não carregado. Não é possível salvar novos itens.")
        return
        
    while True:
        formato = input("Deseja salvar os novos itens na planilha principal? (s/n): ").lower().strip()
        
        if formato == "s":
            estoque.extend(dados)
            salvar_estoque(estoque) 
            print(f"\n[SUCESSO] {len(dados)} novos itens adicionados à planilha.")
            break
        elif formato == "n":
            print("Exportação cancelada. Os novos itens não foram salvos na planilha principal.")
            break
        else:
            print("Opção inválida. Digite s ou n.")
            
def cadastro_em_loop():
    """Implementa o fluxo de cadastro em loop, pilha por item e exportação final."""
    
    global estoque
    
    if estoque is None:
        print("[BLOQUEADO] Estoque principal não carregado. Corrija o arquivo Excel para cadastrar.")
        return
        
    produtos_loop = []
    print("\n--- INICIANDO CADASTRO SIMPLIFICADO ---")
    
    while True:
        resposta = input("Deseja cadastrar um novo item? (s/n): ").lower().strip()
        
        if resposta == "s":
            novo_item = obter_dados_item()
            
            produtos_loop.append(novo_item)
            
            print("\n-- Produto cadastrado! --")
            
            exibir_pilha(produtos_loop, titulo="Pilha de Novos Itens") 
            
        elif resposta == "n":
            break
            
        else:
            print("Opção inválida. Por favor, digite 's' para cadastrar ou 'n' para sair.")
            
    if produtos_loop:
        print("\n--- RESUMO FINAL DA LISTA CADASTRADA ---")
        exibir_pilha(produtos_loop, titulo=f"Total de {len(produtos_loop)} Novos Itens")
        
        menu_exportacao_final(produtos_loop)

# --- PROGRAMA PRINCIPAL ---

estoque = carregar_estoque() 

while True:
    print("\n--- MENU PRINCIPAL ---")
    
    # Se o estoque não carregou, exibe um alerta no menu.
    if estoque is None:
        print("🚨 **MODO DE SEGURANÇA ATIVADO: RECARREGUE O ARQUIVO CORRETO!** 🚨")
    
    print("1. Cadastro Simplificado (Adiciona itens)") 
    print("2. Consultar / Visualizar Estoque") 
    print("3. Excluir produto da pilha") 
    print("4. Sair")
    
    opcao = input("Escolha uma opção: ").strip()

    if opcao == "1":
        cadastro_em_loop()

    elif opcao == "2":
        consultar_ou_visualizar(estoque)

    elif opcao == "3":
        excluir_item(estoque)

    elif opcao == "4":
        print("Saindo do sistema. Até mais!")
        break

    else:
        print("Opção inválida. Escolha um número de 1 a 4.")